import httpx

res = httpx.get("http://127.0.0.1:8000/list-routes")

print("Available routes:")
for route in res.json():
    print(route)

payload = {
    "name": "Alanto",
    "destinations": ["Kinganru", "Facenianorth", "SantaTiesrie"],
    "business": True,
    "distances": [
        "Munich - Munich: 0",
        "Munich - Kinganru: 3",
        "Munich - Facenianorth: 7",
        "Munich - SantaTiesrie: 4",
        "Munich - Mitling: 1",
        "Kinganru - Facenianorth: 2",
        "Kinganru - SantaTiesrie: 1",
        "Kinganru - Mitling: 1",
        "Facenianorth - SantaTiesrie: 5",
        "Facenianorth - Mitling:  3",
        "SantaTiesrie - Mitling: 2",
    ],
}

print("-" * 30)

res = httpx.post("http://127.0.0.1:8000/calculate", json=payload)
if res.status_code == 404:
    print(f"Calculate - {res.status_code} - route not found")
else:
    print(f"Calculate - {res.status_code} - {res.json()}")

print("-" * 30)

res = httpx.get("http://127.0.0.1:8000/business-trips")
if res.status_code == 404:
    print(f"Business trips - {res.status_code} - route not found")
else:
    print(f"Business trips - {res.status_code} - {res.json()}")
