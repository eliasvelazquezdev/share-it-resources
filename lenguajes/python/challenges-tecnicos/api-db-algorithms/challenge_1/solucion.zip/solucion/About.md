
### About

Two endpoints were implemented in the API in order to help penguins minimize travel time on their adventures.

### Routes description

`/calculate`

This endpoint allows you to make a request sending in JSON format the information of a new trip.

It creates a new Penguin in the database with its respective trip and/or updates an existing Penguin by adding the new trip.

Returns the calculation of the cheapest route in terms of travel time between each mandatory destination.

#### Technical description

A modification of Dijkstra's algorithm is used to find the least cost route between the given destinations.

`/business-trips`

This route allows you to perform a GET request that returns: 
* Penguins with most business trips
* Most visited places
* Total number of business trips

#### Technical description

The function business_trips runs three repository functions that interact with the MongoDB database.

### Project architecture

A modular architecture using Services and Repositories was implemented: Services contains all the business logic. Repositories contains the functions that are responsible for interacting with the database.
### How to run

A base API with a DB connection already exists at [`docker-compose.yml`](./docker-compose.yml).

To run, execute the following command:
```bash
docker-compose rm -f; docker-compose -f docker-compose.yml up --build --force-recreate
```

### How to test

Create a virtual env and activate it
```bash
python3 -m venv env; source env/bin/activate
```
Install the dependencies
```bash
pip install -r requirements.txt -r dev-requirements.txt
```
Run the tests
```bash
pytest tests
```
### Aspects to improve

Repository functions could be improved to optimize interactions with the database.

More validations and error messages could be implemented for debugging.



