import pytest
from src.database.models.penguin import Penguin
from src.routes.calculate import calculate
from src.schemas import Trip


@pytest.mark.anyio()
async def test_calculate_route(api_test_client, mock_mongodb):
    """
    GIVEN a new trip
    WHEN submitting a POST request with valid trip data
    THEN expect a successful response with places to travel
    """

    payload = {
        "name": "TestPenguin",
        "destinations": ["Kinganru", "Facenianorth", "SantaTiesrie"],
        "business": True,
        "distances": [
            "Munich - Munich: 0",
            "Munich - Kinganru: 3",
            "Munich - Facenianorth: 7",
            "Munich - SantaTiesrie: 4",
            "Munich - Mitling: 1",
            "Kinganru - Facenianorth: 2",
            "Kinganru - SantaTiesrie: 1",
            "Kinganru - Mitling: 1",
            "Facenianorth - SantaTiesrie: 5",
            "Facenianorth - Mitling: 3",
            "SantaTiesrie - Mitling: 2",
        ],
    }

    # Try
    response = await api_test_client.post("/calculate", json=payload)

    # Test
    assert response.status_code == 200
    result = response.json()
    assert "places_to_travel" in result


@pytest.mark.anyio()
async def test_penguin(api_test_client, mock_mongodb):
    """
    GIVEN an initialized database
    WHEN submitting a POST request with valid trip data
    THEN an update is expected for the existing penguin
    """

    payload = {
        "name": "TestPenguin1",
        "destinations": ["Kinganru", "Facenianorth", "SantaTiesrie"],
        "business": True,
        "distances": [
            "Munich - Munich: 0",
            "Munich - Kinganru: 3",
            "Munich - Facenianorth: 7",
            "Munich - SantaTiesrie: 4",
            "Munich - Mitling: 1",
            "Kinganru - Facenianorth: 2",
            "Kinganru - SantaTiesrie: 1",
            "Kinganru - Mitling: 1",
            "Facenianorth - SantaTiesrie: 5",
            "Facenianorth - Mitling: 3",
            "SantaTiesrie - Mitling: 2",
        ],
    }

    penguin_data = Penguin(name="TestPenguin1", trips=[])
    await penguin_data.insert()

    # Try
    response = await api_test_client.post("/calculate", json=payload)

    # Test
    assert response.status_code == 200
    updated_penguin = await Penguin.get_by_name("TestPenguin1")
    assert updated_penguin.trips[-1].destinations == [
        "Kinganru",
        "Facenianorth",
        "SantaTiesrie",
    ]
    assert updated_penguin.trips[-1].business is True
