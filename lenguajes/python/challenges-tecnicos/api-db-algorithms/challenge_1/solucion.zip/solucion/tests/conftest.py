import pytest

from httpx import AsyncClient
from app import app as fastapi_app_to_test
from src.database import initialize_database
from src.config.base_config import get_config
from mongomock_motor import AsyncMongoMockClient, AsyncMongoMockDatabase


@pytest.fixture()
def anyio_backend() -> str:
    return "asyncio"


@pytest.fixture()
async def mock_db_client(monkeypatch: pytest.MonkeyPatch) -> AsyncMongoMockClient:
    """Mock of the DB Client, use it only if you need low level access."""

    config = get_config()
    mocked_db_client = AsyncMongoMockClient(str(config.DB_URI), tz_aware=True)
    monkeypatch.setattr(initialize_database, "db_client", mocked_db_client)

    # For some reason, the `api_test_client` does not execute the lifespan function. So I initialize ODM there.
    # Otherwise, all beanie docs will fail in tests.
    await initialize_database.initialize_database(client=mocked_db_client)

    return mocked_db_client


@pytest.fixture()
async def mock_mongodb(mock_db_client: AsyncMongoMockClient) -> AsyncMongoMockDatabase:
    """The actual mock of the DB.

    You can use it in tests to populate the DB with initial data or for assertions
    """
    return mock_db_client.get_database()


@pytest.fixture()
def api_test_client(
    mock_mongodb: None,  # noqa: ARG001
) -> AsyncClient:
    """Generates the test client used by endpoint testing."""
    return AsyncClient(app=fastapi_app_to_test, base_url="http://test")
