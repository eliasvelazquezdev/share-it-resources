import pytest
from src.database.models.penguin import Penguin
from src.repositories import get_total_business_trips


@pytest.mark.anyio()
async def test_total_business_trips(api_test_client, mock_mongodb):
    """
    GIVEN an initialized database
    WHEN a GET request is sent
    THEN expect a successful response with the total number of business trips.
    """

    penguin_data = Penguin(
        name="TestPenguin",
        trips=[
            {"destinations": ["Place1", "Place2"], "business": True},
            {"destinations": ["Place3", "Place4"], "business": False},
            {"destinations": ["Place5", "Place6"], "business": True},
            {"destinations": ["Place7", "Place8"], "business": False},
        ],
    )

    await penguin_data.insert()

    # Try
    res = await get_total_business_trips()

    pipeline = [
        {"$unwind": "$trips"},
        {"$match": {"trips.business": True}},
        {"$count": "total_business_trips"},
    ]

    tbt_db = (
        await mock_mongodb[Penguin.Settings.name]
        .aggregate(pipeline)
        .to_list(length=None)
    )
    total_business_trips = tbt_db[0]["total_business_trips"] if tbt_db else 0

    # Test
    assert res == 2
    assert total_business_trips == 2
