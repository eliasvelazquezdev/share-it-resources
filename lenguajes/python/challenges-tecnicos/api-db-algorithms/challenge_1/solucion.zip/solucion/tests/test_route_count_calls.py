import pytest
from src.database.models.example import ExampleModel


@pytest.mark.anyio()
async def test_count_route(api_test_client, mock_mongodb):
    """Test count route"""
    target_n = 6
    response = await api_test_client.get("/count-calls")
    assert {"number_of_calls": 1} == response.json()
    for _ in range(target_n - 2):
        await api_test_client.get("/count-calls")
    response = await api_test_client.get("/count-calls")
    assert {"number_of_calls": target_n} == response.json()

    number_of_docs_in_db = await mock_mongodb[
        ExampleModel.Settings.name
    ].count_documents({})

    assert target_n == number_of_docs_in_db
