from pydantic import BaseModel, Field
from typing import List


class Trip(BaseModel):
    name: str = Field(min_length=2, description="Name must not be empty")
    destinations: List[str]
    business: bool
    distances: List[str]


class CreateTrip(Trip):
    name: None = None
    distances: None = None
