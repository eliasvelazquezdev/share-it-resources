"""Base configuration."""

from typing import Annotated

from pydantic import Field
from pydantic.networks import UrlConstraints
from pydantic_core import MultiHostUrl
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache

MongoSRVDsn = Annotated[
    MultiHostUrl, UrlConstraints(allowed_schemes=["mongodb", "mongodb+srv"])
]


class BaseConfig(BaseSettings):
    """Service configuration.

    All values are fetched from env vars
    """

    DB_URI: MongoSRVDsn = Field(
        description="MongoDB URI, containing username and password",
        examples=["mongodb://admin:admin@mongo:27017/db-name"],
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore",
    )


@lru_cache
def get_config() -> BaseConfig:
    """Memoize accessing the configuration."""
    return BaseConfig()
