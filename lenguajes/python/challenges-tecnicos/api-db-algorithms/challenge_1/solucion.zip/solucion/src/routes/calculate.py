from fastapi import APIRouter, status, Response, HTTPException

from src import schemas
from src.database import models
from src.repositories import create_penguin, add_new_trip
from src.utils import distances_as_graph, add_source_to_destinations
from src.services import DistanceGraph
from src import schemas

router = APIRouter(prefix="/calculate")


@router.post(
    path="",
    description="Find all places that must be visited for the given input.",
    status_code=status.HTTP_200_OK,
)
async def calculate(
    payload: schemas.Trip,
) -> dict:
    """Create a new Penguin or save a new trip. Calculate the least
    cost path for the given destinations.

    Returns: dict with all places that must be visited.
    """

    # Calculate the least cost path
    try:
        destinations_with_source = add_source_to_destinations(
            destinations=payload.destinations
        )  # Start from Munich
        distances = distances_as_graph(distances=payload.distances)
        graph = DistanceGraph(distances)
        places_to_travel = graph.least_cost_path(destinations_with_source)

        if type(places_to_travel) != list:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "Error": f"This request could not be processed: {places_to_travel}"
                },
            )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"Error": f"This request could not be processed: {e}"},
        )

    # Adds a new trip if Penguin already exists
    penguin = await models.Penguin.get_by_name(name=payload.name)
    if penguin:
        new_trip = schemas.CreateTrip(
            destinations=payload.destinations,
            business=payload.business,
        )

        await add_new_trip(penguin, new_trip.dict())  # Update
        return {"places_to_travel": places_to_travel}

    # Create new Penguin
    trip = schemas.CreateTrip(
        destinations=payload.destinations, business=payload.business
    )

    name = payload.name
    await create_penguin(name, trip.dict())  # Create

    return {"places_to_travel": graph.least_cost_path(destinations_with_source)}
