from beanie import Document


class ExampleModel(Document):
    """This is just an empty example document. The documentation for documents can be found at:
    https://beanie-odm.dev/tutorial/defining-a-document/
    """

    class Settings:  # noqa: D106 - missing docstring in nested class.
        name = "example-models"
