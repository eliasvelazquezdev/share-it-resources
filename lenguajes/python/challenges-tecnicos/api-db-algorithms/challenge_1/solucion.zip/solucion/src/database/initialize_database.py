from beanie import init_beanie
from motor.core import AgnosticClient
from motor.motor_asyncio import AsyncIOMotorClient
from src.config.base_config import get_config
from src.database.models.example import ExampleModel
from src.database.models.penguin import Penguin


config = get_config()

db_client = AsyncIOMotorClient(
    str(config.DB_URI),
    tz_aware=True,
)


async def initialize_database(
    client: AgnosticClient = db_client,
) -> None:
    await init_beanie(
        database=client.get_database(),
        document_models=[
            ExampleModel,
            Penguin
        ],
    )
