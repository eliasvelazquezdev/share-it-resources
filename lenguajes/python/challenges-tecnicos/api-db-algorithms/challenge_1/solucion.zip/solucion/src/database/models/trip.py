from typing import List
from pydantic import BaseModel


class Trip(BaseModel):
    destinations: List[str]
    business: bool
