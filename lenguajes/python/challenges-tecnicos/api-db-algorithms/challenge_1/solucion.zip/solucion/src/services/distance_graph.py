from heapq import heapify, heappop, heappush


class DistanceGraph:
    """
    Modification of Dijkstra's algorithm to
    obtain the lowest cost route between
    the given destinations.
    """

    def __init__(self, graph: dict = {}):
        self.graph = graph

    def add_edge(self, node1, node2, weight):
        if node1 not in self.graph:
            self.graph[node1] = {}
        self.graph[node1][node2] = weight

    def shortest_distances(self, source: str):
        distances = {node: float("inf") for node in self.graph}
        predecessors = {node: None for node in self.graph}
        distances[source] = 0

        # Using heapq to init a priority queue
        pq = [(0, source)]
        heapify(pq)

        visited = set()

        while pq:
            current_distance, current_node = heappop(pq)

            if current_node in visited:
                continue
            visited.add(current_node)

            for neighbor, weight in self.graph[current_node].items():
                tentative_distance = current_distance + weight

                if tentative_distance < distances[neighbor]:
                    distances[neighbor] = tentative_distance
                    predecessors[neighbor] = current_node
                    heappush(pq, (tentative_distance, neighbor))

        return distances, predecessors

    def shortest_path(self, source: str, target: str):
        _, predecessors = self.shortest_distances(source)

        path = []
        current_node = target

        while current_node:
            path.append(current_node)
            current_node = predecessors[current_node]

        path.reverse()

        return path

    def least_cost_path(self, destinations: list) -> list:
        """
        Finds the shortest route between each
        consecutive pair of destinations
        """
        total_path = []
        n = len(destinations)

        for i in range(n - 1):
            start = destinations[i]
            end = destinations[i + 1]

            path_seg = self.shortest_path(start, end)

            if total_path:
                total_path.extend(path_seg[1:])
            else:
                total_path.extend(path_seg)

        return total_path
