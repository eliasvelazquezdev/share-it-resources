from fastapi import APIRouter, status, HTTPException
from src.services import get_business_trips_data

router = APIRouter(prefix="/business-trips")


@router.get(
    path="",
    description="Return information about business trips.",
    status_code=status.HTTP_200_OK,
)
async def business_trips() -> dict:
    try:
        response = await get_business_trips_data()

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"Error": "Something went wrong when querying the database."},
        )

    return response
