from src.database.models import Penguin

from typing import List


async def bstr_aggregation(
    match: dict = None,
    group_by_penguin: bool = False,
) -> list:
    """
    Function to perform the business trips aggregation
    with optional filter
    """

    pipeline = [
        {"$unwind": "$trips"},
        {"$match": {"trips.business": True}},
    ]

    # Filter by penguins with most business trips
    if group_by_penguin:
        pipeline.append(
            {
                "$group": {
                    "_id": "$name",
                    "business_trip_count": {"$sum": 1},
                }
            },
        )
        pipeline.append({"$sort": {"business_trip_count": -1}})
    else:
        # Total business trips
        pipeline.append(
            {"$count": "total_business_trips"},
        )

    if match:
        pipeline.insert(0, {"$match": match})

    return await Penguin.aggregate(pipeline).to_list(None)


async def get_total_business_trips() -> int:
    result = await bstr_aggregation()

    if not result:
        return 0

    return result[0]["total_business_trips"]


async def most_visited_places() -> List[str]:
    pipeline = [
        {"$unwind": "$trips"},
        {"$unwind": "$trips.destinations"},
        {
            "$group": {
                "_id": "$trips.destinations",
                "count": {"$sum": 1},
            }
        },
        {"$sort": {"count": -1}},
        {"$limit": 1},
    ]

    result = await Penguin.aggregate(pipeline).to_list(1)

    if not result:
        return []

    visits = result[0]["count"]

    s_pipeline = [
        {"$unwind": "$trips"},
        {"$unwind": "$trips.destinations"},
        {
            "$group": {
                "_id": "$trips.destinations",
                "count": {"$sum": 1},
            }
        },
        {"$match": {"count": visits}},
        {"$project": {"_id": 0, "destination": "$_id"}},
    ]

    most_visited = await Penguin.aggregate(s_pipeline).to_list()

    return [place["destination"] for place in most_visited]
