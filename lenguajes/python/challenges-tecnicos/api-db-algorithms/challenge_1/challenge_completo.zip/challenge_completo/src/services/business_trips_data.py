from src.repositories import (
    get_penguins_with_most_trips,
    most_visited_places,
    get_total_business_trips,
)


async def get_business_trips_data() -> dict:
    most_traveled_penguins = await get_penguins_with_most_trips()
    most_visited = await most_visited_places()
    business_trips = await get_total_business_trips()

    return {
        "penguins_with_most_trips": most_traveled_penguins,
        "most_visited_places": most_visited,
        "total_business_trips": business_trips,
    }
