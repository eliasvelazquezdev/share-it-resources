from fastapi import APIRouter

from src.database.models.example import ExampleModel

router = APIRouter(prefix="/count-calls")


@router.get(
    path="",
)
async def count_calls() -> dict:
    """Count the number of calls for this specific route. To count the calls a new ExampleModel document is created in the DB.

    Returns: dict with number of calls for this specific route
    """

    await ExampleModel().save()
    called_times = await ExampleModel.find_all().count()
    return {"number_of_calls": called_times}
