from typing import List

from src.database.models import Penguin
from src import schemas

from .trip_repository import bstr_aggregation


async def create_penguin(penguin_name: str, trip_data: dict):
    penguin = schemas.CreatePenguin(name=penguin_name, trips=[trip_data])
    new_penguin = Penguin(**penguin.dict())
    return await new_penguin.save()


async def add_new_trip(penguin, trip_data: dict):
    penguin.trips.append(trip_data)
    return await penguin.save()


async def get_penguins_with_most_trips() -> List[str]:
    group = await bstr_aggregation(group_by_penguin=True)

    if not group:
        return []

    max_trips = group[0]["business_trip_count"]

    return [
        penguin["_id"]
        for penguin in group
        if penguin["business_trip_count"] == max_trips
    ]
