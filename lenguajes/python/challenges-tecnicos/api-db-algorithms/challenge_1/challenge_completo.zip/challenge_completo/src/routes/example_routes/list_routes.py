from fastapi import APIRouter, Request


router = APIRouter(prefix="/list-routes")


@router.get(
    path="",
)
async def list_all_available_routes(
    request: Request,
) -> list:
    """List all available routes

    Returns: list with all available routes
    """

    return [{"path": route.path, "name": route.name} for route in request.app.routes]
