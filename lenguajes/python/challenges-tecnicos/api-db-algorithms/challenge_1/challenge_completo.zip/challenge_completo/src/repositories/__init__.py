from .penguin_repository import (
    add_new_trip,
    create_penguin,
    get_penguins_with_most_trips,
)
from .trip_repository import get_total_business_trips, most_visited_places
