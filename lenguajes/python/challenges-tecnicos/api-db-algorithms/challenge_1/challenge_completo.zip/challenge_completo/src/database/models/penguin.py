from beanie import Document

from typing import List
from typing import Optional
from pydantic.fields import Field
from datetime import datetime

from .trip import Trip


class Penguin(Document):
    name: str
    trips: List[Trip]

    created_at: datetime = Field(default_factory=datetime.utcnow)

    @classmethod
    async def get_by_name(self, name: str) -> Optional["Penguin"]:
        return await Penguin.find_one(Penguin.name == name)

    class Settings:
        name = "penguins"
