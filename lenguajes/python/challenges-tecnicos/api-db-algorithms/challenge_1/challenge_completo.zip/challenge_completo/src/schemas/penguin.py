from pydantic import BaseModel
from typing import List


class Penguin(BaseModel):
    name: str


class CreatePenguin(Penguin):
    trips: List[dict]
