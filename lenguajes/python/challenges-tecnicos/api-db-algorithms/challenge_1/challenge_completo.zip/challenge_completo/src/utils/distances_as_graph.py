def get_parts(
    places: str,
) -> list:  # Split the destinations and their travel times
    parts = places.split(" - ")
    subparts = parts[1].split(":")
    return [parts[0], subparts[0], subparts[1]]


def distances_as_graph(distances: list) -> dict:
    """
    Create a dictionary as a graph with destinations
    as nodes and travel times as edge weights.

    Args:
        distances (list): List of destinations and travel times

    Returns:
        dict: Graph with destinations and travel times
    """

    # Ignore travel time from Munich to Munich
    distances.pop(0)

    n = len(distances)
    graph = {}

    for places in range(n):
        s, d, weight = get_parts(distances[places])
        weight = float(weight.strip())

        if s not in graph:
            graph[s] = {}

        if d not in graph:
            graph[d] = {}

        graph[s][d] = weight
        graph[d][s] = weight

    return graph


# Set the departure destination
def add_source_to_destinations(destinations: list):
    destinations_mod = ["Munich"]  # From Munich
    for i in range(len(destinations)):
        destinations_mod.append(destinations[i])

    return destinations_mod
