# CELUS Python Challenge

Challenge for Python Backend developers. For description see [INSTRUCTIONS.md](./INSTRUCTIONS.md).