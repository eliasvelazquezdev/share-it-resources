from fastapi import FastAPI
from src.routes.example_routes import count_calls
from src.routes.example_routes import list_routes
from src.routes import calculate
from src.routes import business_trips
from contextlib import asynccontextmanager
from typing import AsyncGenerator
from src.database.initialize_database import initialize_database


@asynccontextmanager
async def lifespan(
    app: FastAPI,
) -> AsyncGenerator:
    """Application lifespan."""
    await initialize_database()
    yield


app = FastAPI(
    lifespan=lifespan,
)

app.include_router(count_calls.router)
app.include_router(list_routes.router)

app.include_router(calculate.router)
app.include_router(business_trips.router)
