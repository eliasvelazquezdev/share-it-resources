import os

os.environ["DB_URI"] = "mongodb://someone:secret@fake-mongo:27017/fake-db"
